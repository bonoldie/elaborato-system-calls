/// @file fifo.h
/// @brief Contiene la definizioni di variabili e
///         funzioni specifiche per la gestione delle FIFO.

#ifndef _FIFO_HH
#define _FIFO_HH

int getFIFO(char * path,mode_t mode);

#endif